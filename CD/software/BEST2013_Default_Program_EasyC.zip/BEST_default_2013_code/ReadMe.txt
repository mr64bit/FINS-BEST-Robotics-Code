ReadMe.txt
BEST 2013 code (functionally the same as the 2012 code)
Default code, jg revision 7/16/2012 with note changes by dk on 6/21/2013
Motor (control)  Description
Port (joystick or buttons)
m2 (+j3)   m2 and m9 are opposing analog pairs
m3 (+j4)  
m4 (7/8 udlr :  -127 default, -50, +50, +127) 
(suggest servo only)  m4,m7 opp dig pairs
m5 (+j1, limits per d1 and d2) 
 
m6 (+j2, limits per pot on a1)
m7 (7/8udlr, four latched values:  +127 default, +50, -50, -127) (suggest servo only) m4,m7 opp dig pairs
m8 (6u, two values, -127 for released button and +127 for pressed button, was m7) (suggest servo only)
m9 (-j3)   m2 and m9 are opposing analog pairs
 

