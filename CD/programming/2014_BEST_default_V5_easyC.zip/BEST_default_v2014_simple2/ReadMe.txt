BEST Robotics Default Program v2014_simple2
Dallas BEST,  Joel Graber  2014_08_25

 Simple EasyC program to use all motor ports

See Config for motor port and limit switch assignments.

Controller summary:
 Arcade drive on right joystick (1,2)
 Analog motor drive from left joystick (3,4)
 digital motor/servo drive from shoulder buttons 5,6
 dual opposite servo grippers 
    with 4 latched positions from buttons 7 or 8 (either one)
